import unittest

from bot import matching_store, price_to_cents, seller_offer, shopping_candidates


class PriceParsingTests(unittest.TestCase):
    def test_parses_spanish_and_international_price_formats(self):
        self.assertEqual(price_to_cents("1.234,56 €"), 123456)
        self.assertEqual(price_to_cents("$1,234.56"), 123456)
        self.assertEqual(price_to_cents("49,99"), 4999)

    def test_rejects_missing_or_invalid_prices(self):
        self.assertIsNone(price_to_cents(None))
        self.assertIsNone(price_to_cents("Consultar precio"))
        self.assertIsNone(price_to_cents("0 €"))


class RetailerMatchingTests(unittest.TestCase):
    def test_matches_supported_stores_without_case_or_accent_sensitivity(self):
        self.assertEqual(matching_store("Amazon.es"), "Amazon.es")
        self.assertEqual(matching_store("PcComponentes.com"), "PcComponentes")
        self.assertEqual(matching_store("MediaMarkt España"), "MediaMarkt")
        self.assertIsNone(matching_store("Otra tienda"))

    def test_filters_and_deduplicates_shopping_results(self):
        results = shopping_candidates(
            {
                "shopping_results": [
                    {
                        "source": "PcComponentes",
                        "product_id": "1",
                        "title": "Producto",
                        "product_link": "https://example.com/1",
                        "extracted_price": 100.5,
                    },
                    {
                        "source": "PcComponentes",
                        "product_id": "1",
                        "title": "Producto duplicado",
                        "product_link": "https://example.com/1",
                        "extracted_price": 99,
                    },
                    {
                        "source": "Otra tienda",
                        "product_id": "2",
                        "title": "Otro",
                        "product_link": "https://example.com/2",
                        "extracted_price": 90,
                    },
                ]
            }
        )
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["price_cents"], 10050)

    def test_selects_price_from_matching_seller(self):
        offer = seller_offer(
            {
                "sellers_results": {
                    "online_sellers": [
                        {"name": "Otra tienda", "price": "80,00 €"},
                        {
                            "name": "MediaMarkt España",
                            "base_price": "79,99 €",
                            "link": "https://example.com/item",
                        },
                    ]
                }
            },
            "MediaMarkt",
        )
        self.assertEqual(offer, (7999, "https://example.com/item"))


if __name__ == "__main__":
    unittest.main()
